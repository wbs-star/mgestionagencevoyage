package com.calevdeviseor.mvc;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.calevdeviseor.mvc.entity.Achat;
import com.calevdeviseor.mvc.services.IAchatService;

@Controller
public class AchatController {
	@Autowired
	public IAchatService achatservice;

	@RequestMapping(value = "achat")
	public String achat(Model model) {
		List<Achat> achats = achatservice.selectAll(); // on decide de recuperer la "selection de
																				// tout" de achatservice ds une
																				// liste
		if (achats == null) { // on decide de dire que si la liste est vide, dinstancier des achats ds
										// cette liste
			achats = new ArrayList<Achat>();
		}
		model.addAttribute("achats", achats);
		return "achat/achat";
	}

	@RequestMapping(value = "/nouveauachat", method = RequestMethod.GET)
	public String ajouterAchat(Model model, Achat response) {
		Achat achat = new Achat();
		model.addAttribute("achat", achat);

		return "achat/faireachat";
	}

	@RequestMapping(value = "/enregistrerachat", method = RequestMethod.POST)
	public String enregistrerAchat(Model model, Achat achat) {
		if (achat.getIdAchat() != null) {
			achatservice.update(achat);
		} else {
			achatservice.save(achat);
		}

		return "redirect:/achat";
	}

	@RequestMapping(value = "/modifierachat/{idAchat}", method = RequestMethod.GET)
	public String modifierAchat(Model model, @PathVariable Long idAchat) {
		if (idAchat != null) {
			Achat achat = achatservice.getById(idAchat);
			if (achat != null) {
				model.addAttribute("achat", achat);
			}
		}
		return "achat/faireachat";
	}

	@RequestMapping(value = "/supprimerachat/{idAchat}", method = RequestMethod.GET)
	public String supprimerAchat(Model model, @PathVariable Long idAchat) {
		if (idAchat != null) {

			achatservice.remove(idAchat);
		}

		return "redirect:/achat";
	}
}
