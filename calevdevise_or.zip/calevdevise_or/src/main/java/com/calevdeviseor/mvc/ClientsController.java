package com.calevdeviseor.mvc;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.calevdeviseor.mvc.services.IClientsService;
import com.calevdeviseor.mvc.entity.Clients;

@Controller
public class ClientsController {
	@Autowired
	public IClientsService clientsservice;
	
	@RequestMapping(value = "/clients")
	public String clients(Model model) {
		List<Clients> clients=clientsservice.selectAll(); //on decide de recuperer la "selection de tout" de clientsservice ds une liste 
		if(clients==null) { //on decide de dire que si la liste  est vide, dinstancier des clientss ds cette liste
			clients=new ArrayList<Clients>();
		}
		model.addAttribute("clients",clients);
		return "clients/clients";
	}
	
	@RequestMapping(value = "/nouveau", method=RequestMethod.GET)
	public String ajouterClients(Model model,Clients response) {		
		Clients clients= new Clients();
		model.addAttribute("clients",clients);
		
		return "clients/ajouterClients";
		}	
	
		
	  @RequestMapping(value = "/enregistrer", method=RequestMethod.POST) 
	  public String enregistrerClients(Model model, Clients clients) { 
		  if (clients.getIdClient() != null){
			  clientsservice.update(clients);
		  }
		  else {clientsservice.save(clients);}
		  
		  return "redirect:/clients";
		  }
	
	  @RequestMapping(value = "/modifier/{idClients}", method=RequestMethod.GET) 
	  public String modifierClients(Model model, @PathVariable Long idClients) 
	  { if (idClients !=null) {
	  Clients clients = clientsservice.getById(idClients); 
	  if(clients!=null) {
	  model.addAttribute("clientss",clients); } } 
	  return "clients/ajouterClients"; }
	 
	  
	  @RequestMapping(value="/supprimer/{idClients}",method=RequestMethod.GET)
      public String supprimerClients(Model model,@PathVariable Long idClients) {
                    if (idClients!=null) {
                                 Clients clients= clientsservice.getById(idClients);
                                 
                                 clientsservice.remove(idClients);
                    }
               
                    return "redirect:/clients";}

}
