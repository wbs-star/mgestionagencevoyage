package com.calevdeviseor.mvc;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.calevdeviseor.mvc.entity.CotationQuotidienne;
import com.calevdeviseor.mvc.services.ICotationService;

@Controller
public class CotationQuotidienneController {
	@Autowired
	public ICotationService cotationQuotidienneservice;

	@RequestMapping(value = "cotation")
	public String cotationQuotidienne(Model model) {
		List<CotationQuotidienne> cotationQuotidiennes = cotationQuotidienneservice.selectAll(); // on decide de recuperer la "selection de
																				// tout" de cotationQuotidienneservice ds une
																				// liste
		if (cotationQuotidiennes == null) { // on decide de dire que si la liste est vide, dinstancier des cotationQuotidiennes ds
										// cette liste
			cotationQuotidiennes = new ArrayList<CotationQuotidienne>();
		}
		model.addAttribute("cotationQuotidiennes", cotationQuotidiennes);
		return "cotation/cotation";
	}

	@RequestMapping(value = "/nouveaucotation", method = RequestMethod.GET)
	public String ajouterCotationQuotidienne(Model model, CotationQuotidienne response) {
		CotationQuotidienne cotationQuotidienne = new CotationQuotidienne();
		model.addAttribute("cotationQuotidienne", cotationQuotidienne);

		return "cotation/ajouterCotation";
	}

	@RequestMapping(value = "/enregistrercotation", method = RequestMethod.POST)
	public String enregistrerCotationQuotidienne(Model model, CotationQuotidienne cotationQuotidienne) {
		if (cotationQuotidienne.getIdCotation() != null) {
			cotationQuotidienneservice.update(cotationQuotidienne);
		} else {
			cotationQuotidienneservice.save(cotationQuotidienne);
		}

		return "redirect:/cotation";
	}

	@RequestMapping(value = "/modifiercotation/{idCotationQuotidienne}", method = RequestMethod.GET)
	public String modifierCotationQuotidienne(Model model, @PathVariable Long idCotationQuotidienne) {
		if (idCotationQuotidienne != null) {
			CotationQuotidienne cotationQuotidienne = cotationQuotidienneservice.getById(idCotationQuotidienne);
			if (cotationQuotidienne != null) {
				model.addAttribute("cotationQuotidienne", cotationQuotidienne);
			}
		}
		return "cotation/ajouterCotation";
	}

	@RequestMapping(value = "/supprimercotationQuotidienne/{idCotationQuotidienne}", method = RequestMethod.GET)
	public String supprimerCotationQuotidienne(Model model, @PathVariable Long idCotationQuotidienne) {
		if (idCotationQuotidienne != null) {

			cotationQuotidienneservice.remove(idCotationQuotidienne);
		}

		return "redirect:/cotation";
	}
}
