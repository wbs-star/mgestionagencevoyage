package com.calevdeviseor.mvc;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.calevdeviseor.mvc.entity.DevisesBillets;
import com.calevdeviseor.mvc.services.IDevisesBilletsService;

@Controller
public class DevisesBilletsController {
	@Autowired
	public IDevisesBilletsService devisesBilletsservice;

	@RequestMapping(value = "devise")
	public String devisesBillets(Model model) {
		List<DevisesBillets> devisesBilletss = devisesBilletsservice.selectAll(); // on decide de recuperer la "selection de
																				// tout" de devisesBilletsservice ds une
																				// liste
		if (devisesBilletss == null) { // on decide de dire que si la liste est vide, dinstancier des devisesBilletss ds
										// cette liste
			devisesBilletss = new ArrayList<DevisesBillets>();
		}
		model.addAttribute("devisesBilletss", devisesBilletss);
		return "devise/devise";
	}

	@RequestMapping(value = "/nouveaudevise", method = RequestMethod.GET)
	public String ajouterDevisesBillets(Model model, DevisesBillets response) {
		DevisesBillets devisesBillets = new DevisesBillets();
		model.addAttribute("devisesBillets", devisesBillets);

		return "devise/Ajouterdevise";
	}

	@RequestMapping(value = "/enregistrerdevise", method = RequestMethod.POST)
	public String enregistrerDevisesBillets(Model model, DevisesBillets devisesBillets) {
		if (devisesBillets.getIdDevisesBillets() != null) {
			devisesBilletsservice.update(devisesBillets);
		} else {
			devisesBilletsservice.save(devisesBillets);
		}

		return "redirect:/devise";
	}

	@RequestMapping(value = "/modifierdevise/{idDevisesBillets}", method = RequestMethod.GET)
	public String modifierDevisesBillets(Model model, @PathVariable Long idDevisesBillets) {
		if (idDevisesBillets != null) {
			DevisesBillets devisesBillets = devisesBilletsservice.getById(idDevisesBillets);
			if (devisesBillets != null) {
				model.addAttribute("devisesBillets", devisesBillets);
			}
		}
		return "devise/Ajouterdevise";
	}

	@RequestMapping(value = "/supprimerdevise/{idDevisesBillets}", method = RequestMethod.GET)
	public String supprimerDevisesBillets(Model model, @PathVariable Long idDevisesBillets) {
		if (idDevisesBillets != null) {

			devisesBilletsservice.remove(idDevisesBillets);
		}

		return "redirect:/devise";
	}
}
