package com.calevdeviseor.mvc;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.calevdeviseor.mvc.entity.Lingot;
import com.calevdeviseor.mvc.entity.Lingot;
import com.calevdeviseor.mvc.services.ILingotService;

@Controller
public class LingotController {
	@Autowired
	public ILingotService lingotservice;
	
	@RequestMapping(value = "lingot")
	public String lingot(Model model) {
		List<Lingot> lingot=lingotservice.selectAll(); //on decide de recuperer la "selection de tout" de lingotservice ds une liste 
		if(lingot==null) { //on decide de dire que si la liste  est vide, dinstancier des lingots ds cette liste
			lingot=new ArrayList<Lingot>();
		}
		model.addAttribute("lingot",lingot);
		return "lingot/lingot";
	}
	
	@RequestMapping(value = "/nouveaulingot", method=RequestMethod.GET)
	public String ajouterLingot(Model model,Lingot response) {		
		Lingot lingot= new Lingot();
		model.addAttribute("lingot",lingot);
		
		return "lingot/ajouterLingot";
		}	
	
		
	  @RequestMapping(value = "/enregistrerlingot", method=RequestMethod.POST) 
	  public String enregistrerLingot(Model model, Lingot lingot) { 
		  if (lingot.getIdLingot() != null){
			  lingotservice.update(lingot);
		  }
		  else {lingotservice.save(lingot);}
		  
		  return "redirect:/lingot";
		  }
	
	  @RequestMapping(value = "/modifierlingot/{idLingot}", method=RequestMethod.GET) 
	  public String modifierLingot(Model model, @PathVariable Long idLingot) 
	  { if (idLingot !=null) {
	  Lingot lingot = lingotservice.getById(idLingot); 
	  if(lingot!=null) {
	  model.addAttribute("lingots",lingot); } } 
	  return "lingot/ajouterLingot"; }
	 
	  
	  @RequestMapping(value="/supprimerlingot/{idLingot}",method=RequestMethod.GET)
      public String supprimerLingot(Model model,@PathVariable Long idLingot) {
                    if (idLingot!=null) {
                                 Lingot lingot= lingotservice.getById(idLingot);
                                 
                                 lingotservice.remove(idLingot);
                    }
               
                    return "redirect:/lingot";}
}
