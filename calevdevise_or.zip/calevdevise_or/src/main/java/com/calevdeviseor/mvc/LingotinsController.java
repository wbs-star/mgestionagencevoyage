package com.calevdeviseor.mvc;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.calevdeviseor.mvc.entity.Lingotins;
import com.calevdeviseor.mvc.services.ILingotinsService;

@Controller
public class LingotinsController {
	@Autowired
	public ILingotinsService lingotinsservice;
	
	@RequestMapping(value = "/lingotins")
	public String lingotins(Model model) {
		List<Lingotins> lingotins=lingotinsservice.selectAll(); //on decide de recuperer la "selection de tout" de lingotinsservice ds une liste 
		if(lingotins==null) { //on decide de dire que si la liste  est vide, dinstancier des lingotinss ds cette liste
			lingotins=new ArrayList<Lingotins>();
		}
		model.addAttribute("lingotins",lingotins);
		return "lingotins";
	}
}
