package com.calevdeviseor.mvc;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.calevdeviseor.mvc.entity.Particulier;
import com.calevdeviseor.mvc.services.IParticulierService;

@Controller

public class ParticulierController {
	@Autowired
	public IParticulierService particulierservice;
	
	@RequestMapping(value = "particulier")
	public String particulier(Model model) {
		List<Particulier> particulier=particulierservice.selectAll(); //on decide de recuperer la "selection de tout" de particulierservice ds une liste 
		if(particulier==null) { //on decide de dire que si la liste  est vide, dinstancier des particuliers ds cette liste
			particulier=new ArrayList<Particulier>();
		}
		model.addAttribute("particulier",particulier);
		return "particulier/particulier";
	}
	
	@RequestMapping(value = "/nouveauparticulier", method=RequestMethod.GET)
	public String ajouterParticulier(Model model,Particulier response) {		
		Particulier particulier= new Particulier();
		model.addAttribute("particulier",particulier);
		
		return "particulier/ajouterParticulier";
		}	
	
		
	  @RequestMapping(value = "/enregistrerparticulier", method=RequestMethod.POST) 
	  public String enregistrerParticulier(Model model, Particulier particulier) { 
		  if (particulier.getIdParticulier() != null){
			  particulierservice.update(particulier);
		  }
		  else {particulierservice.save(particulier);}
		  
		  return "redirect:/particulier";
		  }
	
	  @RequestMapping(value = "/modifierparticulier/{idParticulier}", method=RequestMethod.GET) 
	  public String modifierParticulier(Model model, @PathVariable Long idParticulier) 
	  { if (idParticulier !=null) {
	  Particulier particulier = particulierservice.getById(idParticulier); 
	  if(particulier!=null) {
	  model.addAttribute("particulier",particulier); } } 
	  return "particulier/ajouterParticulier"; }
	 
	  
	  @RequestMapping(value="/supprimerparticulier/{idParticulier}",method=RequestMethod.GET)
      public String supprimerParticulier(Model model,@PathVariable Long idParticulier) {
                    if (idParticulier!=null) {
                                 Particulier particulier= particulierservice.getById(idParticulier);
                                 
                                 particulierservice.remove(idParticulier);
                    }
               
                    return "redirect:/particulier";}
}
