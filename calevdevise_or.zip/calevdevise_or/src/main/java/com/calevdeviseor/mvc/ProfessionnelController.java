package com.calevdeviseor.mvc;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.calevdeviseor.mvc.entity.Professionnel;
import com.calevdeviseor.mvc.services.IProfessionnelService;

@Controller
public class ProfessionnelController {
	@Autowired
	public IProfessionnelService professionnelservice;

	@RequestMapping(value = "professionnel")
	public String professionnel(Model model) {
		List<Professionnel> professionnels = professionnelservice.selectAll(); 
		if (professionnels == null) { 
			professionnels = new ArrayList<Professionnel>();
		}
		model.addAttribute("professionnels", professionnels);
		return "professionnel/professionnel";
	}

	@RequestMapping(value = "/nouveauprofessionnel", method = RequestMethod.GET)
	public String ajouterProfessionnel(Model model, Professionnel response) {
		Professionnel professionnel = new Professionnel();
		model.addAttribute("professionnel", professionnel);

		return "professionnel/ajouterProfessionnel";
	}

	@RequestMapping(value = "/enregistrerprofessionnel", method = RequestMethod.POST)
	public String enregistrerProfessionnel(Model model, Professionnel professionnel) {
		if (professionnel.getIdprofessionnel() != null) {
			professionnelservice.update(professionnel);
		} else {
			professionnelservice.save(professionnel);
		}

		return "redirect:/professionnel";
	}

	@RequestMapping(value = "/modifierprofessionnel/{idProfessionnel}", method = RequestMethod.GET)
	public String modifierProfessionnel(Model model, @PathVariable Long idProfessionnel) {
		if (idProfessionnel != null) {
			Professionnel professionnel = professionnelservice.getById(idProfessionnel);
			if (professionnel != null) {
				model.addAttribute("professionnel", professionnel);
			}
		}
		return "professionnel/ajouterProfessionnel";
	}

	@RequestMapping(value = "/supprimerprofessionnel/{idProfessionnel}", method = RequestMethod.GET)
	public String supprimerProfessionnel(Model model, @PathVariable Long idProfessionnel) {
		if (idProfessionnel != null) {

			professionnelservice.remove(idProfessionnel);
		}

		return "redirect:/professionnel";
	}
}
