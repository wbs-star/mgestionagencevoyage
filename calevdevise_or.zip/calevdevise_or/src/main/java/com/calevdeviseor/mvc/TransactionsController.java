package com.calevdeviseor.mvc;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.calevdeviseor.mvc.entity.Transactions;
import com.calevdeviseor.mvc.services.ITransactionsService;

@Controller
public class TransactionsController {
	@Autowired
	public ITransactionsService transactionsservice;
	
	@RequestMapping(value = "/transactions")
	public String transactions(Model model) {
		List<Transactions> transactions=transactionsservice.selectAll(); //on decide de recuperer la "selection de tout" de transactionsservice ds une liste 
		if(transactions==null) { //on decide de dire que si la liste  est vide, dinstancier des transactionss ds cette liste
			transactions=new ArrayList<Transactions>();
		}
		model.addAttribute("transactions",transactions);
		return "transactions/transactions";
	}
	
	@RequestMapping(value = "/nouveautransactions", method=RequestMethod.GET)
	public String ajouterTransactions(Model model,Transactions response) {		
		Transactions transactions= new Transactions();
		model.addAttribute("transactions",transactions);
		
		return "transactions/ajouterTransactions";
		}	
	
		
	  @RequestMapping(value = "/enregistrertransactions", method=RequestMethod.POST) 
	  public String enregistrerTransactions(Model model, Transactions transactions) { 
		  if (transactions.getIdtransaction() != null){
			  transactionsservice.update(transactions);
		  }
		  else {transactionsservice.save(transactions);}
		  
		  return "redirect:/transactions";
		  }
	
	  @RequestMapping(value = "/modifier/{idTransactions}", method=RequestMethod.GET) 
	  public String modifierTransactions(Model model, @PathVariable Long idTransactions) 
	  { if (idTransactions !=null) {
	  Transactions transactions = transactionsservice.getById(idTransactions); 
	  if(transactions!=null) {
	  model.addAttribute("transactionss",transactions); } } 
	  return "transactions/ajouterTransactions"; }
	 
	  
	  @RequestMapping(value="/supprimer/{idTransactions}",method=RequestMethod.GET)
      public String supprimerTransactions(Model model,@PathVariable Long idTransactions) {
                    if (idTransactions!=null) {
                                 Transactions transactions= transactionsservice.getById(idTransactions);
                                 
                                 transactionsservice.remove(idTransactions);
                    }
               
                    return "redirect:/transactions";}
}
