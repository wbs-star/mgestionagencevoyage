package com.calevdeviseor.mvc.dao;

import com.calevdeviseor.mvc.entity.Achat;

public interface IAchatDao extends IGenericDao<Achat> {

}
