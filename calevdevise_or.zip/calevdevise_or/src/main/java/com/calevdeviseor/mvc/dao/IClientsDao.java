package com.calevdeviseor.mvc.dao;

import com.calevdeviseor.mvc.dao.IGenericDao;
import com.calevdeviseor.mvc.entity.Clients;

public interface IClientsDao extends IGenericDao<Clients> {

}
