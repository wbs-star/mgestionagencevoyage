package com.calevdeviseor.mvc.dao;

public interface IConservationDao {

}
