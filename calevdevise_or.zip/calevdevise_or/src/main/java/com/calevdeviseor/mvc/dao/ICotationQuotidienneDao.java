package com.calevdeviseor.mvc.dao;

import com.calevdeviseor.mvc.entity.CotationQuotidienne;
import com.calevdeviseor.mvc.dao.IGenericDao;
public interface ICotationQuotidienneDao extends IGenericDao<CotationQuotidienne> {

}
