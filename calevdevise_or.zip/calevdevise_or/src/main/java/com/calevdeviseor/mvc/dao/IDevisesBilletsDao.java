package com.calevdeviseor.mvc.dao;

import com.calevdeviseor.mvc.entity.DevisesBillets;

public interface IDevisesBilletsDao extends IGenericDao<DevisesBillets> {

}
