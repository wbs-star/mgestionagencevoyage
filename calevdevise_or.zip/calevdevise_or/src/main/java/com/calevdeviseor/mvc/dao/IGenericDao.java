package com.calevdeviseor.mvc.dao;

import java.util.List;

public interface IGenericDao<T> {
	public T save(T entity);
	public T update(T entity);
	public T getById(Long id);
	public List<T> selectAll ();
	public List<T> selectAll (String sortField, String sort);

	public void remove (Long id);
}
