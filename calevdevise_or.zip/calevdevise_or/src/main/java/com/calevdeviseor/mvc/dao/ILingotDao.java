package com.calevdeviseor.mvc.dao;

import com.calevdeviseor.mvc.entity.Lingot;

public interface ILingotDao extends IGenericDao<Lingot> {

}
