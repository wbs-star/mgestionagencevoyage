package com.calevdeviseor.mvc.dao;

import com.calevdeviseor.mvc.entity.Lingotins;

public interface ILingotinsDao extends IGenericDao<Lingotins> {

}
