package com.calevdeviseor.mvc.dao;

import com.calevdeviseor.mvc.entity.Particulier;

public interface IParticulierDao extends IGenericDao<Particulier>{

}
