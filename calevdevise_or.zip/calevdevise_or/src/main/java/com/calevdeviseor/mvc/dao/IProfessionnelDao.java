package com.calevdeviseor.mvc.dao;

import com.calevdeviseor.mvc.entity.Professionnel;

public interface IProfessionnelDao extends IGenericDao<Professionnel> {

}
