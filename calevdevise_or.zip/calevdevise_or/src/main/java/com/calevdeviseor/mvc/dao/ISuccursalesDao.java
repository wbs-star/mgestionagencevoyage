package com.calevdeviseor.mvc.dao;

public interface ISuccursalesDao {

}
