package com.calevdeviseor.mvc.dao;

import com.calevdeviseor.mvc.entity.Transactions;

public interface ITransactionsDao extends IGenericDao<Transactions> {

}
