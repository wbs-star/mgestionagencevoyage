package com.calevdeviseor.mvc.dao.Impl;

import com.calevdeviseor.mvc.dao.IAchatDao;
import com.calevdeviseor.mvc.entity.Achat;
import com.calevdeviseor.mvc.entity.Clients;

public class AchatDaoImpl extends GenericDaoImpl<Achat> implements IAchatDao {

}
