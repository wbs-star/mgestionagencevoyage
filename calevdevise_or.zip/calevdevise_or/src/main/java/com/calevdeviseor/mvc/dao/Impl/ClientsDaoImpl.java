package com.calevdeviseor.mvc.dao.Impl;

import com.calevdeviseor.mvc.dao.IClientsDao;
import com.calevdeviseor.mvc.dao.Impl.GenericDaoImpl;
import com.calevdeviseor.mvc.entity.Clients;

public class ClientsDaoImpl extends GenericDaoImpl<Clients> implements IClientsDao {

}
