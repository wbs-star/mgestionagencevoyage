package com.calevdeviseor.mvc.dao.Impl;

import com.calevdeviseor.mvc.dao.IClientsDao;
import com.calevdeviseor.mvc.dao.ICotationQuotidienneDao;
import com.calevdeviseor.mvc.entity.CotationQuotidienne;

public class CotationQuotidienneDaoImpl extends GenericDaoImpl<CotationQuotidienne> implements ICotationQuotidienneDao{

}
