package com.calevdeviseor.mvc.dao.Impl;

import com.calevdeviseor.mvc.dao.IDevisesBilletsDao;
import com.calevdeviseor.mvc.entity.DevisesBillets;
import com.calevdeviseor.mvc.entity.Clients;

public class DevisesBilletsDaoImpl extends GenericDaoImpl<DevisesBillets> implements IDevisesBilletsDao {

}
