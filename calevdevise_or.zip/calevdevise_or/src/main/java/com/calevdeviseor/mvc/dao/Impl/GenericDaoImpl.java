package com.calevdeviseor.mvc.dao.Impl;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.calevdeviseor.mvc.dao.IGenericDao;

@SuppressWarnings("unchecked")
public class GenericDaoImpl <T> implements IGenericDao<T> {
	@PersistenceContext
	EntityManager em;
	
	private Class<T> type;	
	public Class<T> getType() {
		return type;
	}
	
	public GenericDaoImpl() {// on encapsule le constructeur
		super();
		Type t = getClass().getGenericSuperclass();
		ParameterizedType pt = (ParameterizedType)t;// ici on cr�e l'objet
		type = (Class<T>)pt.getActualTypeArguments()[0];
	}

	@Override
	public T save(T entity) {
		// enregistre un entity T
				em.persist(entity);
				return entity;
	}

	@Override
	public T update(T entity) {
		return em.merge(entity);
	}

	@Override
	public T getById(Long id) {
		// recherche par id
				return em.find(type,id);
	}

	@Override
	public List<T> selectAll() {
		Query query = em.createQuery("select t from "+type.getSimpleName()+" t");
		return query.getResultList();
	}

	@Override
	public List<T> selectAll(String sortField, String sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void remove(Long id) {
		T tab = em.getReference(type, id);
		em.remove(tab);
		
	}
}
