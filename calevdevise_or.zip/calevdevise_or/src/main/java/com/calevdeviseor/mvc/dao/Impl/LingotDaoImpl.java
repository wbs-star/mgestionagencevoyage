package com.calevdeviseor.mvc.dao.Impl;

import com.calevdeviseor.mvc.dao.ILingotDao;
import com.calevdeviseor.mvc.dao.ILingotinsDao;
import com.calevdeviseor.mvc.entity.Lingot;

public class LingotDaoImpl extends GenericDaoImpl<Lingot> implements ILingotDao{

}
