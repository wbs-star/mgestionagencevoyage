package com.calevdeviseor.mvc.dao.Impl;

import com.calevdeviseor.mvc.dao.IClientsDao;
import com.calevdeviseor.mvc.dao.ILingotinsDao;
import com.calevdeviseor.mvc.entity.Lingotins;

public class LingotinsDaoImpl extends GenericDaoImpl<Lingotins> implements ILingotinsDao {

}
