package com.calevdeviseor.mvc.dao.Impl;

import com.calevdeviseor.mvc.dao.IParticulierDao;
import com.calevdeviseor.mvc.entity.Particulier;

public class ParticulierDaoImpl extends GenericDaoImpl<Particulier> implements IParticulierDao {

}
