package com.calevdeviseor.mvc.dao.Impl;

public class ProduitsDevisesDaoImpl {

}
