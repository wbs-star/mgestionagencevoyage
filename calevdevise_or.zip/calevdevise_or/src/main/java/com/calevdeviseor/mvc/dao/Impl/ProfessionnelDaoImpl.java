package com.calevdeviseor.mvc.dao.Impl;

import com.calevdeviseor.mvc.dao.IProfessionnelDao;
import com.calevdeviseor.mvc.entity.Professionnel;

public class ProfessionnelDaoImpl extends GenericDaoImpl<Professionnel> implements IProfessionnelDao{

}
