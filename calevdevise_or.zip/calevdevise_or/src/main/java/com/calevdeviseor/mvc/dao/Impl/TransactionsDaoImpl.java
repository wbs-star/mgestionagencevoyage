package com.calevdeviseor.mvc.dao.Impl;

import com.calevdeviseor.mvc.dao.ITransactionsDao;
import com.calevdeviseor.mvc.entity.Transactions;

public class TransactionsDaoImpl extends GenericDaoImpl<Transactions> implements ITransactionsDao {

}
