package com.calevdeviseor.mvc.dao.Impl;

public class VenteDaoImpl {

}
