package com.calevdeviseor.mvc.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="ACHAT")
public class Achat implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="IDAchat")
	private Long idAchat;
	private String produit;
	private String montant;
	private Date dateachat;

	
	@ManyToOne
	@JoinColumn(name="Particulier_id")
	private Particulier particulier;
	@ManyToOne
	@JoinColumn(name="Professionnel_id")
	private Professionnel professionnel;
	@ManyToOne
	@JoinColumn(name="ProduitsOr_id")
	private ProduitsOr produitsOr;
	@ManyToOne
	@JoinColumn(name="ProduitsDevises_id")
	private ProduitsDevises produitsDevises;
	
	public Particulier getParticulier() {
		return particulier;
	}
	public void setParticulier(Particulier particulier) {
		this.particulier = particulier;
	}
	
	
	public Professionnel getProfessionnel() {
		return professionnel;
	}
	public void setProfessionnel(Professionnel professionnel) {
		this.professionnel = professionnel;
	}
	
	
	public ProduitsOr getProduitsOr() {
		return produitsOr;
	}
	public void setProduitsOr(ProduitsOr produitsOr) {
		this.produitsOr = produitsOr;
	}

	
	public ProduitsDevises getProduitsDevises() {
		return produitsDevises;
	}
	public void setProduitsDevises(ProduitsDevises produitsDevises) {
		this.produitsDevises = produitsDevises;
	}


	public Achat(String produit, String montant, Date dateachat) {
		super();
		this.produit = produit;
		this.montant = montant;
		this.dateachat = dateachat;
		
	}


	public Achat() {
		super();
	}


	public Long getIdAchat() {
		return idAchat;
	}


	public void setIdAchat(Long idAchat) {
		this.idAchat = idAchat;
	}


	public String getProduit() {
		return produit;
	}


	public void setProduit(String produit) {
		this.produit = produit;
	}


	public String getMontant() {
		return montant;
	}


	public void setMontant(String montant) {
		this.montant = montant;
	}


	public Date getDateachat() {
		return dateachat;
	}


	public void setDateachat(Date dateachat) {
		this.dateachat = dateachat;
	}


	


	@Override
	public String toString() {
		return "Achat [idAchat=" + idAchat + ", produit=" + produit + ", montant=" + montant + ", dateachat="
				+ dateachat + ", particulier=" + particulier + ", professionnel=" + professionnel + ", produitsOr="
				+ produitsOr + ", produitsDevises=" + produitsDevises + "]";
	}

	
	
	

}
