package com.calevdeviseor.mvc.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="CLIENTS")
public class Clients implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="IDClients")
	private Long idClient;
	@Column(name="NomClients")
	private String nomClient;
	
	@Column(name="ADRESSEClient")
	private String adresseClient;
	@Column(name="VilleClient")
	private String VilleClient;
	@Column(name="codePostalClient")
	private int codePostalClient;
	@Column(name="PaysClient")
	private String PaysClient;
	
	public Clients(String nomClient) {
		super();
		this.nomClient = nomClient;
	}
	public Clients() {
		super();
	}
	public Long getIdClient() {
		return idClient;
	}
	public void setIdClient(Long idClient) {
		this.idClient = idClient;
	}
	
	
	public String getNomClient() {
		return nomClient;
	}
	public void setNomClient(String nomClient) {
		this.nomClient = nomClient;
	}
	public String getAdresseClient() {
		return adresseClient;
	}
	public void setAdresseClient(String adresseClient) {
		this.adresseClient = adresseClient;
	}
	public String getVilleClient() {
		return VilleClient;
	}
	public void setVilleClient(String villeClient) {
		VilleClient = villeClient;
	}
	public int getCodePostalClient() {
		return codePostalClient;
	}
	public void setCodePostalClient(int codePostalClient) {
		this.codePostalClient = codePostalClient;
	}
	public String getPaysClient() {
		return PaysClient;
	}
	public void setPaysClient(String paysClient) {
		PaysClient = paysClient;
	}
	public Clients(String adresseClient, String villeClient, int codePostalClient, String paysClient) {
		super();
		this.adresseClient = adresseClient;
		VilleClient = villeClient;
		this.codePostalClient = codePostalClient;
		PaysClient = paysClient;
	}
	@Override
	public String toString() {
		return "Clients [idClient=" + idClient + ", adresseClient=" + adresseClient + ", VilleClient=" + VilleClient
				+ ", codePostalClient=" + codePostalClient + ", PaysClient=" + PaysClient + "]";
	}

	
	
}
