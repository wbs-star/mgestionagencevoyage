package com.calevdeviseor.mvc.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Cotation")
public class CotationQuotidienne implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="IDCotation")
	private Long idCotation;
	@Column(name="datecotation")
	private Date datecotation;
	@Column(name="valeurcotation")
	private float valeurcotation;
	public CotationQuotidienne(Date datecotation, float valeurcotation) {
		super();
		this.datecotation = datecotation;
		this.valeurcotation = valeurcotation;
	}
	public CotationQuotidienne() {
		super();
	}
	public Long getIdCotation() {
		return idCotation;
	}
	public void setIdCotation(Long idCotation) {
		this.idCotation = idCotation;
	}
	public Date getDatecotation() {
		return datecotation;
	}
	public void setDatecotation(Date datecotation) {
		this.datecotation = datecotation;
	}
	public float getValeurcotation() {
		return valeurcotation;
	}
	public void setValeurcotation(float valeurcotation) {
		this.valeurcotation = valeurcotation;
	}
	@Override
	public String toString() {
		return "CotationQuotidienne [idCotation=" + idCotation + ", datecotation=" + datecotation + ", valeurcotation="
				+ valeurcotation + "]";
	}
	
	
}
