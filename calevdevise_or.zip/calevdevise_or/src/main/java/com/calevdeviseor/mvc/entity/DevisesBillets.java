package com.calevdeviseor.mvc.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="DEVISESBILLETS")
public class DevisesBillets {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="IDDevisesBillets")
	private Long idDevisesBillets;
	@Column(name="valeur")
	private double valeur;
	@Column(name="imageBillet")
	private String imageBillet;
	
	public Long getIdDevisesBillets() {
		return idDevisesBillets;
	}
	public void setIdDevisesBillets(Long idDevisesBillets) {
		this.idDevisesBillets = idDevisesBillets;
	}
	public double getValeur() {
		return valeur;
	}
	public void setValeur(double valeur) {
		this.valeur = valeur;
	}
	public String getImageBillet() {
		return imageBillet;
	}
	public void setImageBillet(String imageBillet) {
		this.imageBillet = imageBillet;
	}
	public DevisesBillets(double valeur, String imageBillet) {
		super();
		this.valeur = valeur;
		this.imageBillet = imageBillet;
	}
	public DevisesBillets() {
		super();
	}
	
	
	
}   
    