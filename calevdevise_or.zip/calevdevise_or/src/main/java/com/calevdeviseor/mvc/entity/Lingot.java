package com.calevdeviseor.mvc.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="LINGOT")
public class Lingot {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="IDLingot")
	private Long idLingot;
	@Column(name="poidsLingot")
    private String poidsLingot;
	@Column(name="cotationLingot")
    private double cotationLingot;
	
	
	
	public Long getIdLingot() {
		return idLingot;
	}
	public void setIdLingot(Long idLingot) {
		this.idLingot = idLingot;
	}
	public String getPoidsLingot() {
		return poidsLingot;
	}
	public void setPoidsLingot(String poidsLingot) {
		this.poidsLingot = poidsLingot;
	}
	public double getCotationLingot() {
		return cotationLingot;
	}
	public void setCotationLingot(double cotationLingot) {
		this.cotationLingot = cotationLingot;
	}
	public Lingot(String poidsLingot, double cotationLingot) {
		super();
		this.poidsLingot = poidsLingot;
		this.cotationLingot = cotationLingot;
	}
	public Lingot() {
		super();
	}
	
	
}
