package com.calevdeviseor.mvc.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="LINGOTINS")
public class Lingotins implements Serializable  {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="IDLingotins")
	private Long idLingotins;
	@Column(name="poidsLingotins")
	private int poidsLingotins;
	@Column(name="cotationLingotins")
    private double cotationLingotins;
	public Long getIdLingotins() {
		return idLingotins;
	}
	public void setIdLingotins(Long idLingotins) {
		this.idLingotins = idLingotins;
	}
	public int getPoidsLingotins() {
		return poidsLingotins;
	}
	public void setPoidsLingotins(int poidsLingotins) {
		this.poidsLingotins = poidsLingotins;
	}
	public double getCotationLingotins() {
		return cotationLingotins;
	}
	public void setCotationLingotins(double cotationLingotins) {
		this.cotationLingotins = cotationLingotins;
	}
	public Lingotins(int poidsLingotins, double cotationLingotins) {
		super();
		this.poidsLingotins = poidsLingotins;
		this.cotationLingotins = cotationLingotins;
	}
	
	
}
