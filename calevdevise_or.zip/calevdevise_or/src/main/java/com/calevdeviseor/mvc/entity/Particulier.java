package com.calevdeviseor.mvc.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "PARTICULIER")
public class Particulier implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "IDParticulier")
	private Long idParticulier;
	private String nom;
	private String prenom;
	private String adresseParticulier;
	private String villeParticulier;
	private String paysParticulier;
	private String codePostalPart;
	private String emailPart;


	public Particulier() {
		super();
	}

	public Long getIdParticulier() {
		return idParticulier;
	}

	public void setIdParticulier(Long idParticulier) {
		this.idParticulier = idParticulier;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getAdresseParticulier() {
		return adresseParticulier;
	}

	public void setAdresseParticulier(String adresseParticulier) {
		this.adresseParticulier = adresseParticulier;
	}

	public String getVilleParticulier() {
		return villeParticulier;
	}

	public void setVilleParticulier(String villeParticulier) {
		this.villeParticulier = villeParticulier;
	}

	public Particulier(String villeParticulier) {
		super();
		this.villeParticulier = villeParticulier;
	}

	public String getPaysParticulier() {
		return paysParticulier;
	}

	public void setPaysParticulier(String paysParticulier) {
		this.paysParticulier = paysParticulier;
	}

	public String getCodePostalPart() {
		return codePostalPart;
	}

	public void setCodePostalPart(String codePostalPart) {
		this.codePostalPart = codePostalPart;
	}

	public String getEmailPart() {
		return emailPart;
	}

	public void setEmailPart(String emailPart) {
		this.emailPart = emailPart;
	}

	public Particulier(String nom, String prenom, String adresseParticulier, String paysParticulier,
			String codePostalPart, String emailPart) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.adresseParticulier = adresseParticulier;
		this.paysParticulier = paysParticulier;
		this.codePostalPart = codePostalPart;
		this.emailPart = emailPart;
	}

	@Override
	public String toString() {
		return "Particulier [idParticulier=" + idParticulier + ", nom=" + nom + ", prenom=" + prenom
				+ ", adresseParticulier=" + adresseParticulier + ", villeParticulier=" + villeParticulier
				+ ", paysParticulier=" + paysParticulier + ", codePostalPart=" + codePostalPart + ", emailPart="
				+ emailPart + "]";
	}

}
