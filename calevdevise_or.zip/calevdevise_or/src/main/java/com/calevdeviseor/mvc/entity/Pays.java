package com.calevdeviseor.mvc.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="PAYS")
public class Pays {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="IDPays")
	private Long idPays;
	@Column(name="nomPays")
	private String nomPays;
	@Column(name="drapeauPays")
	private int drapeauPays;
}
