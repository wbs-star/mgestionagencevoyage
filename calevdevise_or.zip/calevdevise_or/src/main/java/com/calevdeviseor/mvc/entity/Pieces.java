package com.calevdeviseor.mvc.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="PIECES")
public class Pieces implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="IDPieces")
	private Long idPieces;
	@Column(name="nomPiece")
	private String nomPiece;
	@Column(name="paysPiece")
	private String paysPiece;
	@Column(name="effigie")
	private String effigie;
	public Long getIdPieces() {
		return idPieces;
	}
	public void setIdPieces(Long idPieces) {
		this.idPieces = idPieces;
	}
	public String getNomPiece() {
		return nomPiece;
	}
	public void setNomPiece(String nomPiece) {
		this.nomPiece = nomPiece;
	}
	public String getPaysPiece() {
		return paysPiece;
	}
	public void setPaysPiece(String paysPiece) {
		this.paysPiece = paysPiece;
	}
	public String getEffigie() {
		return effigie;
	}
	public void setEffigie(String effigie) {
		this.effigie = effigie;
	}
	public Pieces(String nomPiece, String paysPiece, String effigie) {
		super();
		this.nomPiece = nomPiece;
		this.paysPiece = paysPiece;
		this.effigie = effigie;
	}
	
	
	
}
