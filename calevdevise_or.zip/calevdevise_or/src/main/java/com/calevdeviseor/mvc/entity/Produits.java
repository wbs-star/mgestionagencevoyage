package com.calevdeviseor.mvc.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="PRODUITS")
public class Produits {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="IDProduits;")
	private Long idProduits;
	@Column(name="IDProduitsOr")
	private Long idProduitsOr;
	@Column(name="IDProduitsDevises")
	private Long idProduitsDevises;
	
	
	public Long getIdProduits() {
		return idProduits;
	}
	public void setIdProduits(Long idProduits) {
		this.idProduits = idProduits;
	}
	public Long getIdProduitsOr() {
		return idProduitsOr;
	}
	public void setIdProduitsOr(Long idProduitsOr) {
		this.idProduitsOr = idProduitsOr;
	}
	public Long getIdProduitsDevises() {
		return idProduitsDevises;
	}
	public void setIdProduitsDevises(Long idProduitsDevises) {
		this.idProduitsDevises = idProduitsDevises;
	}
	
	
}
