package com.calevdeviseor.mvc.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="PRODUITSDEVISES")
public class ProduitsDevises {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="IDProduitsDevives")
	private Long idProduitsDevives;

	public Long getIdProduitsDevives() {
		return idProduitsDevives;
	}

	public void setIdProduitsDevives(Long idProduitsDevives) {
		this.idProduitsDevives = idProduitsDevives;
	}

//	@OneToMany(mappedBy="idProduitsDevives")
//	private List<Achat> achat;
//	public List<Achat> getAchat() {
//		return achat;
//	}
//	public void setAchat(List<Achat> achat) {
//		this.achat = achat;
//	}
}
