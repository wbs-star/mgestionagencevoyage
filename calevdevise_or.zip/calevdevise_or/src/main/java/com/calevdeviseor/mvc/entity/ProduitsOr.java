package com.calevdeviseor.mvc.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="PRODUITSOR")
public class ProduitsOr {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="IDProduitsOr")
	private Long idProduitsOr;

	public Long getIdProduitsOr() {
		return idProduitsOr;
	}

	public void setIdProduitsOr(Long idProduitsOr) {
		this.idProduitsOr = idProduitsOr;
	}
	
//	@OneToMany(mappedBy="idProduitsOr")
//	private List<Achat> achat;
//	public List<Achat> getAchat() {
//		return achat;
//	}
//	public void setAchat(List<Achat> achat) {
//		this.achat = achat;
//	}
}
