package com.calevdeviseor.mvc.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Professionnels") 
public class Professionnel {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "IDPROFESSIONNEL")
	private Long idprofessionnel;
	private String raisonsociale;
	private int codeAPE;
	private int siret;	
	private String adressePro;
	private String villePro;
	private String codepostalPro;
	private String paysPro;
	
//	@OneToMany(mappedBy="idprofessionnel")
//	private List<Achat> achat;
//	public List<Achat> getAchat() {
//		return achat;
//	}
//	public void setAchat(List<Achat> achat) {
//		this.achat = achat;
//	}
	
	public Professionnel(String raisonsociale, int codeAPE, int siret, String adressePro, String villePro,
			String codepostalPro, String paysPro) {
		super();
		this.raisonsociale = raisonsociale;
		this.codeAPE = codeAPE;
		this.siret = siret;
		this.adressePro = adressePro;
		this.villePro = villePro;
		this.codepostalPro = codepostalPro;
		this.paysPro = paysPro;
	}

	public Long getIdprofessionnel() {
		return idprofessionnel;
	}

	public void setIdprofessionnel(Long idprofessionnel) {
		this.idprofessionnel = idprofessionnel;
	}

	public String getRaisonsociale() {
		return raisonsociale;
	}

	public void setRaisonsociale(String raisonsociale) {
		this.raisonsociale = raisonsociale;
	}

	public int getCodeAPE() {
		return codeAPE;
	}

	public void setCodeAPE(int codeAPE) {
		this.codeAPE = codeAPE;
	}

	public int getSiret() {
		return siret;
	}

	public void setSiret(int siret) {
		this.siret = siret;
	}

	public String getAdressePro() {
		return adressePro;
	}

	public void setAdressePro(String adressePro) {
		this.adressePro = adressePro;
	}

	public String getVillePro() {
		return villePro;
	}

	public void setVillePro(String villePro) {
		this.villePro = villePro;
	}

	public String getCodepostalPro() {
		return codepostalPro;
	}

	public void setCodepostalPro(String codepostalPro) {
		this.codepostalPro = codepostalPro;
	}

	public String getPaysPro() {
		return paysPro;
	}

	public void setPaysPro(String paysPro) {
		this.paysPro = paysPro;
	}

	public Professionnel() {
		super();
	}

	@Override
	public String toString() {
		return "Professionnel [idprofessionnel=" + idprofessionnel + ", raisonsociale=" + raisonsociale + ", codeAPE="
				+ codeAPE + ", siret=" + siret + ", adressePro=" + adressePro + ", villePro=" + villePro
				+ ", codepostalPro=" + codepostalPro + ", paysPro=" + paysPro + "]";
	}
	
	
	
	
}
