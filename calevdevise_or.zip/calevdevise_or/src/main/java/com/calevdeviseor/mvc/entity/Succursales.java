package com.calevdeviseor.mvc.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="SUCCURSALES")
public class Succursales implements Serializable  {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="IDSucc")
	private Long idSucc;
	@Column(name="paysSucc")
	private String paysSucc;
	@Column(name="villeSucc")
	private String villeSucc;
	public Long getIdSucc() {
		return idSucc;
	}
	public void setIdSucc(Long idSucc) {
		this.idSucc = idSucc;
	}
	public String getPaysSucc() {
		return paysSucc;
	}
	public void setPaysSucc(String paysSucc) {
		this.paysSucc = paysSucc;
	}
	public String getVilleSucc() {
		return villeSucc;
	}
	public void setVilleSucc(String villeSucc) {
		this.villeSucc = villeSucc;
	}
	public Succursales(String paysSucc, String villeSucc) {
		super();
		this.paysSucc = paysSucc;
		this.villeSucc = villeSucc;
	}
	@Override
	public String toString() {
		return "Succursales [idSucc=" + idSucc + ", paysSucc=" + paysSucc + ", villeSucc=" + villeSucc + "]";
	}
	
	
	
}
