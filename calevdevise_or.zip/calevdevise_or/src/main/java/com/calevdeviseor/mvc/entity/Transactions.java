package com.calevdeviseor.mvc.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="CLIENTS")
public class Transactions implements Serializable  {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="IDTransactions")
	private Long idtransaction;
	@Column(name="IDProduitsOr")
	private Long idProduitsOr;
	@Column(name="IDProduitsDevises")
	private Long idProduitsDevises;
	@Column(name="IDSucc")
	private Long idSucc;
	 private float montant;
	 private String typeTransaction;
	 private Date dateTransaction;
	public Transactions(Long idProduitsOr, Long idProduitsDevises, Long idSucc, float montant, String typeTransaction,
			Date dateTransaction) {
		super();
		this.idProduitsOr = idProduitsOr;
		this.idProduitsDevises = idProduitsDevises;
		this.idSucc = idSucc;
		this.montant = montant;
		this.typeTransaction = typeTransaction;
		this.dateTransaction = dateTransaction;
	}
	public Transactions() {
		super();
	}
	public Long getIdtransaction() {
		return idtransaction;
	}
	public void setIdtransaction(Long idtransaction) {
		this.idtransaction = idtransaction;
	}
	public Long getIdProduitsOr() {
		return idProduitsOr;
	}
	public void setIdProduitsOr(Long idProduitsOr) {
		this.idProduitsOr = idProduitsOr;
	}
	public Long getIdProduitsDevises() {
		return idProduitsDevises;
	}
	public void setIdProduitsDevises(Long idProduitsDevises) {
		this.idProduitsDevises = idProduitsDevises;
	}
	public Long getIdSucc() {
		return idSucc;
	}
	public void setIdSucc(Long idSucc) {
		this.idSucc = idSucc;
	}
	public float getMontant() {
		return montant;
	}
	public void setMontant(float montant) {
		this.montant = montant;
	}
	public String getTypeTransaction() {
		return typeTransaction;
	}
	public void setTypeTransaction(String typeTransaction) {
		this.typeTransaction = typeTransaction;
	}
	public Date getDateTransaction() {
		return dateTransaction;
	}
	public void setDateTransaction(Date dateTransaction) {
		this.dateTransaction = dateTransaction;
	}
	@Override
	public String toString() {
		return "Transactions [idtransaction=" + idtransaction + ", idProduitsOr=" + idProduitsOr
				+ ", idProduitsDevises=" + idProduitsDevises + ", idSucc=" + idSucc + ", montant=" + montant
				+ ", typeTransaction=" + typeTransaction + ", dateTransaction=" + dateTransaction + "]";
	}
	
	 
	 
}
