package com.calevdeviseor.mvc.entity;

public class Vente {

}
