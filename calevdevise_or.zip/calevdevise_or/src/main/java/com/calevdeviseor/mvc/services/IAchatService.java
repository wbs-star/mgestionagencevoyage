package com.calevdeviseor.mvc.services;

import java.util.List;

import com.calevdeviseor.mvc.entity.Achat;

public interface IAchatService {
	public Achat save(Achat entity);
	public Achat update(Achat entity);
	public Achat getById(Long id);
	public List<Achat> selectAll ();
	public List<Achat> selectAll (String sortField, String sort);
	public void remove (Long id);
}
