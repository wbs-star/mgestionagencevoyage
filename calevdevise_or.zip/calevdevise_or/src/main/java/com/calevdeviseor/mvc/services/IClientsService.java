package com.calevdeviseor.mvc.services;

import java.util.List;

import com.calevdeviseor.mvc.entity.Clients;

public interface IClientsService {
	public Clients save(Clients entity);
	public Clients update(Clients entity);
	public Clients getById(Long id);
	public List<Clients> selectAll ();
	public List<Clients> selectAll (String sortField, String sort);
	public void remove (Long id);
}
