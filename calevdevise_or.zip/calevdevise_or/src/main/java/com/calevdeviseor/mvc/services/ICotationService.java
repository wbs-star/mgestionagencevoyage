package com.calevdeviseor.mvc.services;

import java.util.List;

import com.calevdeviseor.mvc.entity.CotationQuotidienne;

public interface ICotationService {
	public CotationQuotidienne save(CotationQuotidienne entity);
	public CotationQuotidienne update(CotationQuotidienne entity);
	public CotationQuotidienne getById(Long id);
	public List<CotationQuotidienne> selectAll ();
	public List<CotationQuotidienne> selectAll (String sortField, String sort);
	public void remove (Long id);
}
