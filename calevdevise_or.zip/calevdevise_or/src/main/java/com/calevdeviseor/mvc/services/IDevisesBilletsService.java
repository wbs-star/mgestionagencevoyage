package com.calevdeviseor.mvc.services;

import java.util.List;

import com.calevdeviseor.mvc.entity.DevisesBillets;

public interface IDevisesBilletsService {
	public DevisesBillets save(DevisesBillets entity);
	public DevisesBillets update(DevisesBillets entity);
	public DevisesBillets getById(Long id);
	public List<DevisesBillets> selectAll ();
	public List<DevisesBillets> selectAll (String sortField, String sort);
	public void remove (Long id);
}
