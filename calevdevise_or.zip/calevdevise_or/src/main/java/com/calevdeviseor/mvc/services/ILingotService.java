package com.calevdeviseor.mvc.services;

import java.util.List;

import com.calevdeviseor.mvc.entity.Lingot;

public interface ILingotService {
	public Lingot save(Lingot entity);
	public Lingot update(Lingot entity);
	public Lingot getById(Long id);
	public List<Lingot> selectAll ();
	public List<Lingot> selectAll (String sortField, String sort);
	public void remove (Long id);
}
