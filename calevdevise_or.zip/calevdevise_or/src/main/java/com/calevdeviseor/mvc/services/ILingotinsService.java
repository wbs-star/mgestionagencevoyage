package com.calevdeviseor.mvc.services;

import java.util.List;

import com.calevdeviseor.mvc.entity.Lingotins;

public interface ILingotinsService {
//	public Lingotins save(Lingotins entity);
//	public Lingotins update(Lingotins entity);
	public Lingotins getById(Long id);
	public List<Lingotins> selectAll ();
	public List<Lingotins> selectAll (String sortField, String sort);
	public void remove (Long id);
}
