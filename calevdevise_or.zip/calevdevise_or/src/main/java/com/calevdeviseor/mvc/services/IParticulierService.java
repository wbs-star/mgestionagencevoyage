package com.calevdeviseor.mvc.services;

import java.util.List;

import com.calevdeviseor.mvc.entity.Particulier;

public interface IParticulierService {
	public Particulier save(Particulier entity);
	public Particulier update(Particulier entity);
	public Particulier getById(Long id);
	public List<Particulier> selectAll ();
	public List<Particulier> selectAll (String sortField, String sort);
	public void remove (Long id);
}
