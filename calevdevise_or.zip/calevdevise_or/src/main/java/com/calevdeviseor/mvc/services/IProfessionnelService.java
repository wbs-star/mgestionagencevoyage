package com.calevdeviseor.mvc.services;

import java.util.List;

import com.calevdeviseor.mvc.entity.Professionnel;

public interface IProfessionnelService {
	public Professionnel save(Professionnel entity);
	public Professionnel update(Professionnel entity);
	public Professionnel getById(Long id);
	public List<Professionnel> selectAll ();
	public List<Professionnel> selectAll (String sortField, String sort);
	public void remove (Long id);
}
