package com.calevdeviseor.mvc.services;

import java.util.List;

import com.calevdeviseor.mvc.entity.Transactions;

public interface ITransactionsService {
	public Transactions save(Transactions entity);
	public Transactions update(Transactions entity);
	public Transactions getById(Long id);
	public List<Transactions> selectAll ();
	public List<Transactions> selectAll (String sortField, String sort);
	public void remove (Long id);
}
