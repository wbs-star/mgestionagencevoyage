package com.calevdeviseor.mvc.services.Impl;

import java.util.List;

import com.calevdeviseor.mvc.dao.IAchatDao;
import com.calevdeviseor.mvc.entity.Achat;
import com.calevdeviseor.mvc.services.IAchatService;
import com.calevdeviseor.mvc.services.IClientsService;

public class AchatServiceImpl implements IAchatService {
	
	private IAchatDao dao;

	public void setDao(IAchatDao dao) {
		this.dao = dao;
	}

	@Override
	public Achat save(Achat entity) {
		// TODO Auto-generated method stub
		return dao.save(entity);
	}

	@Override
	public Achat update(Achat entity) {
		// TODO Auto-generated method stub
		return dao.update(entity);
	}

	@Override
	public Achat getById(Long id) {
		// TODO Auto-generated method stub
		return dao.getById(id);
	}

	@Override
	public List<Achat> selectAll() {
		// TODO Auto-generated method stub
		return dao.selectAll();
	}

	@Override
	public List<Achat> selectAll(String sortField, String sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void remove(Long id) {
		dao.remove(id);
	}

}
