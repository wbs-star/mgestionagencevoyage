package com.calevdeviseor.mvc.services.Impl;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.calevdeviseor.mvc.entity.Clients;
import com.calevdeviseor.mvc.services.IClientsService;
import com.calevdeviseor.mvc.dao.IClientsDao;
@Transactional
public class ClientsServiceImpl implements IClientsService {

	private IClientsDao dao;

	public void setDao(IClientsDao dao) {
		this.dao = dao;
	}
	
	@Override
	public Clients save(Clients entity) {
		// TODO Auto-generated method stub
		return dao.save(entity);
	}

	@Override
	public Clients update(Clients entity) {
		// TODO Auto-generated method stub
		return dao.update(entity);
	}

	@Override
	public Clients getById(Long id) {
		// TODO Auto-generated method stub
		return dao.getById(id);
	}

	@Override
	public List<Clients> selectAll() {
		// TODO Auto-generated method stub
		return dao.selectAll();
	}

	@Override
	public List<Clients> selectAll(String sortField, String sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void remove(Long id) {
		// TODO Auto-generated method stub
		dao.remove(id);
	}

}
