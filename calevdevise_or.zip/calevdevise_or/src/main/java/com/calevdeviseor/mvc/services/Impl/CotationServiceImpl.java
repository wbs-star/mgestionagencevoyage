package com.calevdeviseor.mvc.services.Impl;

import java.util.List;


import com.calevdeviseor.mvc.dao.ICotationQuotidienneDao;
import com.calevdeviseor.mvc.entity.CotationQuotidienne;
import com.calevdeviseor.mvc.services.ICotationService;

public class CotationServiceImpl implements ICotationService{
	
	private ICotationQuotidienneDao dao;

	public void setDao(ICotationQuotidienneDao dao) {
		this.dao = dao;
	}

	@Override
	public CotationQuotidienne save(CotationQuotidienne entity) {
		// TODO Auto-generated method stub
		return dao.save(entity);
	}

	@Override
	public CotationQuotidienne update(CotationQuotidienne entity) {
		// TODO Auto-generated method stub
		return dao.update(entity);
	}

	@Override
	public CotationQuotidienne getById(Long id) {
		// TODO Auto-generated method stub
		return dao.getById(id);
	}

	@Override
	public List<CotationQuotidienne> selectAll() {
		// TODO Auto-generated method stub
		return dao.selectAll();
	}

	@Override
	public List<CotationQuotidienne> selectAll(String sortField, String sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void remove(Long id) {
		dao.remove(id);
		
	}

}
