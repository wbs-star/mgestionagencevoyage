package com.calevdeviseor.mvc.services.Impl;

import java.util.List;

import com.calevdeviseor.mvc.dao.IDevisesBilletsDao;
import com.calevdeviseor.mvc.entity.DevisesBillets;
import com.calevdeviseor.mvc.services.IDevisesBilletsService;
import com.calevdeviseor.mvc.services.IClientsService;

public class DevisesBilletsServiceImpl implements IDevisesBilletsService {
	
	private IDevisesBilletsDao dao;

	public void setDao(IDevisesBilletsDao dao) {
		this.dao = dao;
	}

	@Override
	public DevisesBillets save(DevisesBillets entity) {
		// TODO Auto-generated method stub
		return dao.save(entity);
	}

	@Override
	public DevisesBillets update(DevisesBillets entity) {
		// TODO Auto-generated method stub
		return dao.update(entity);
	}

	@Override
	public DevisesBillets getById(Long id) {
		// TODO Auto-generated method stub
		return dao.getById(id);
	}

	@Override
	public List<DevisesBillets> selectAll() {
		// TODO Auto-generated method stub
		return dao.selectAll();
	}

	@Override
	public List<DevisesBillets> selectAll(String sortField, String sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void remove(Long id) {
		dao.remove(id);
	}

}
