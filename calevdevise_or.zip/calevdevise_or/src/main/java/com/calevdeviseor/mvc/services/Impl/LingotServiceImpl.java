package com.calevdeviseor.mvc.services.Impl;

import java.util.List;

import com.calevdeviseor.mvc.dao.ILingotDao;
import com.calevdeviseor.mvc.entity.Lingot;
import com.calevdeviseor.mvc.services.ILingotService;

public class LingotServiceImpl implements ILingotService{
	private ILingotDao dao;

	public void setDao(ILingotDao dao) {
		this.dao = dao;
	}

	@Override
	public Lingot getById(Long id) {
		// TODO Auto-generated method stub
		return dao.getById(id);
	}

	@Override
	public List<Lingot> selectAll() {
		// TODO Auto-generated method stub
		return dao.selectAll();
	}

	@Override
	public List<Lingot> selectAll(String sortField, String sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void remove(Long id) {
		dao.remove(id);
		
	}

	@Override
	public Lingot save(Lingot entity) {
		// TODO Auto-generated method stub
		return dao.save(entity);
	}

	@Override
	public Lingot update(Lingot entity) {
		// TODO Auto-generated method stub
		return dao.update(entity);
	}

}
