package com.calevdeviseor.mvc.services.Impl;

import java.util.List;

import com.calevdeviseor.mvc.dao.ILingotinsDao;
import com.calevdeviseor.mvc.entity.Lingotins;
import com.calevdeviseor.mvc.services.ILingotinsService;

public class LingotinsServiceImpl implements ILingotinsService {
	private ILingotinsDao dao;

	public void setDao(ILingotinsDao dao) {
		this.dao = dao;
	}

	@Override
	public Lingotins getById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Lingotins> selectAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Lingotins> selectAll(String sortField, String sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void remove(Long id) {
		// TODO Auto-generated method stub
		
	}

}
