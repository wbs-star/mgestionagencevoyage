package com.calevdeviseor.mvc.services.Impl;

import java.util.List;

import com.calevdeviseor.mvc.dao.IClientsDao;
import com.calevdeviseor.mvc.dao.IParticulierDao;
import com.calevdeviseor.mvc.entity.Particulier;
import com.calevdeviseor.mvc.services.IParticulierService;

public class ParticulierServiceImpl implements IParticulierService {
	private IParticulierDao dao;

	public void setDao(IParticulierDao dao) {
		this.dao = dao;
	}

	@Override
	public Particulier save(Particulier entity) {
		// TODO Auto-generated method stub
		return dao.save(entity);
	}

	@Override
	public Particulier update(Particulier entity) {
		// TODO Auto-generated method stub
		return dao.update(entity);
	}

	@Override
	public Particulier getById(Long id) {
		// TODO Auto-generated method stub
		return dao.getById(id);
	}

	@Override
	public List<Particulier> selectAll() {
		// TODO Auto-generated method stub
		return dao.selectAll();
	}

	@Override
	public List<Particulier> selectAll(String sortField, String sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void remove(Long id) {
		dao.remove(id);
		
	}

}
