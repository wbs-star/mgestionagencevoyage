package com.calevdeviseor.mvc.services.Impl;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.calevdeviseor.mvc.dao.IProfessionnelDao;
import com.calevdeviseor.mvc.entity.Professionnel;
import com.calevdeviseor.mvc.services.IProfessionnelService;

@Transactional
public class ProfessionnelServiceImpl implements IProfessionnelService {
	
	private IProfessionnelDao dao;

	public void setDao(IProfessionnelDao dao) {
		this.dao = dao;
	}
	
	
	@Override
	public Professionnel save(Professionnel entity) {
		// TODO Auto-generated method stub
		return dao.save(entity);
	}

	@Override
	public Professionnel update(Professionnel entity) {
		// TODO Auto-generated method stub
		return dao.update(entity);
	}

	@Override
	public Professionnel getById(Long id) {
		// TODO Auto-generated method stub
		return dao.getById(id);
	}

	@Override
	public List<Professionnel> selectAll() {
		// TODO Auto-generated method stub
		return dao.selectAll();
	}

	@Override
	public List<Professionnel> selectAll(String sortField, String sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void remove(Long id) {
		dao.remove(id);
		
	}

}
