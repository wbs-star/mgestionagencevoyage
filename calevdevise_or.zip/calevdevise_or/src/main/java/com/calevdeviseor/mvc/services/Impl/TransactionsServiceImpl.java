package com.calevdeviseor.mvc.services.Impl;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.calevdeviseor.mvc.dao.ITransactionsDao;

import com.calevdeviseor.mvc.entity.Transactions;
import com.calevdeviseor.mvc.services.ITransactionsService;
@Transactional
public class TransactionsServiceImpl implements ITransactionsService {
	private ITransactionsDao dao;

	public void setDao(ITransactionsDao dao) {
		this.dao = dao;
	}

	@Override
	public Transactions save(Transactions entity) {
		// TODO Auto-generated method stub
		return dao.save(entity);
	}

	@Override
	public Transactions update(Transactions entity) {
		// TODO Auto-generated method stub
		return dao.update(entity);
	}

	@Override
	public Transactions getById(Long id) {
		// TODO Auto-generated method stub
		return dao.getById(id);
	}

	@Override
	public List<Transactions> selectAll() {
		// TODO Auto-generated method stub
		return dao.selectAll();
	}

	@Override
	public List<Transactions> selectAll(String sortField, String sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void remove(Long id) {
		dao.remove(id);
		
	}
}
