/*$(document).ready(function() {
	$('a[href=clients]').on('click',function(event) {
		event.preventDefault();
		if($('body').children().length<6)
			{$.ajax({
				url :"${ urlEnregistrer}",
				data : $("form ").serialize(),
				succes : function(result){
					var catalog='';
					result.forEach(function(nextWork){
						catalog=catalog.contact(nextWork.idSalarie+" ("+nextWork.nom+")"+" ("+nextWork.prenom+")" +" ("+nextWork.numsecu+") <BR/>");
								});

						$("a[href=clients]").after('<br>'+catalog);
					}
				
			});
			
			}
	});
	
});*/